<?php
include "../config/Database.php";
include "../object/pemesanan.php";

$database = new Database();
$db = $database->getConnection();

$pemesanan = new Pemesanan($db);

//ambil data pemesanan
$result = $pemesanan->readALL();
$num = $result->rowCount();
?>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Pegawai.xls");
	?>

	<center>
		<h1>Data Pemesanan Kendaraan</h1>
	</center>
 
	<table border="1">
		<tr>
			<th>No</th>
			<th>Nama Driver</th>
			<th>Jenis Mobil</th>
			<th>Penempatan Jalur</th>
            <th>Pihak Setuju</th>
		</tr>
        <?php
        $no = 1;
        while ($row = $result->fetch(PDO::FETCH_ASSOC)){
            extract($row);
        ?>
		<tr>
			<td><?= $no ?></td>
			<td><?= $Namadriver ?></td>
			<td><?= $Jenismobil ?></td>
			<td><?= $Penempatanjalur ?></td>
            <td><?= $Pihaksetuju ?></td>
		</tr>
        <?php
                $no += 1;
        }
        ?>
	</table>
