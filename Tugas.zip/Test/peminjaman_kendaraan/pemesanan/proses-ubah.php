<?php
if ($_POST) {
    include "../config/Database.php";
    include "../object/pemesanan.php";

    $database = new Database();
    $db = $database->getConnection();

    $pemesanan = new pemesanan($db);

    // Correct property assignments
    $pemesanan->Namadriver = $_POST["namadriver"];
    $pemesanan->Jenismobil = $_POST["enismobil"];
    $pemesanan->Penempatanjalur = $_POST["penempatanjalur"];
    $pemesanan->Pihaksetuju = $_POST["Pihaksetuju"];
    $pemesanan->ID = $_POST['id'];

    $pemesanan->update();
}

header("Location: http://localhost/app_perpus/pemesanan/index.php");
?>