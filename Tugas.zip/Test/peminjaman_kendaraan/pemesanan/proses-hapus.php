<?php
if ($_GET["ID"]) {
    include "../config/Database.php";
    include "../object/pemesanan.php";

    $database = new Database();
    $db = $database->getConnection();

    $pemesanan = new Pemesanan($db);
    $pemesanan->ID = $_GET["ID"];

    $pemesanan->delete();
}

header("Location: http://localhost/app_perpus/pemesanan/index.php");
?>