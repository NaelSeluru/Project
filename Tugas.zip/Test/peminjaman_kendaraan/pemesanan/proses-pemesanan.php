<?php
if ($_POST) {
    include "../config/Database.php";
    include "../object/pemesanan.php";

    $database = new Database();
    $db = $database->getConnection();

    $pemesanan = new Pemesanan($db);

    $pemesanan->Namadriver = $_POST["namadriver"];
    $pemesanan->Jenismobil = $_POST["jenismobil"];
    $pemesanan->Penempatanjalur = $_POST["penempatanjalur"];
    $pemesanan->Pihaksetuju = $_POST["pihaksetuju"];

    $pemesanan->create();    
}

header("Location: http://localhost/peminjaman_kendaraan/pemesanan/index.php");
?>