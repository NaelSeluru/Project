<?php

class Pengguna {

    private $conn;
    private $table_name = "pengguna";
    
    public $ID;
    public $Email;
    public $Password;

    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    function create() {
        $query = "INSERT INTO " . $this->table_name . " (Email, Password) VALUES (:Email, :Password)";
        $result = $this->conn->prepare($query);
        
        $this->Email = htmlspecialchars(strip_tags($this->Email));
        $this->Password = htmlspecialchars(strip_tags($this->Password));
        
        $result->bindParam(":Email", $this->Email);
        $result->bindParam(":Password", $this->Password);
        
        if($result->execute()) {
            return true;
        } else {
            return false;
        }
    }
    
    function readALL() {
        $query = "SELECT * FROM " . $this->table_name;

        $result = $this->conn->prepare($query);
        $result->execute();

        return $result;
    }
    
    function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);
        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->Email = $row["Email"];
        $this->Password = $row["Password"];
    }

    function update() {
        $query = "UPDATE " . $this->table_name . " SET Email = :Email, Password = :Password WHERE ID = :ID";
        $result = $this->conn->prepare($query);
    
        $this->Email = htmlspecialchars(strip_tags($this->Email));
        $this->Password = htmlspecialchars(strip_tags($this->Password));
    
        $result->bindParam(":Email", $this->Email);
        $result->bindParam(":Password", $this->Password);
        $result->bindParam(":ID", $this->ID);

        $result->execute();
    }

    function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);

        $result->execute();
    }

    function authenticate() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE Email = :Email AND Password = :Password";
    
        $result = $this->conn->prepare($query);
    
        $this->Email=htmlspecialchars(strip_tags($this->Email));
        $this->Password=htmlspecialchars(strip_tags($this->Password));
    
        $result->bindParam(":Email", $this->Email);
        $result->bindParam(":Password", $this->Password);
        
        $result->execute();
    
        if($result->rowCount() > 0) {
            $pengguna = $result->fetch(PDO::FETCH_ASSOC);
    
            $_SESSION["email"] = $pengguna["Email"];
            
            return true;
        } else {
            return false;
        }
    }
}
?>
