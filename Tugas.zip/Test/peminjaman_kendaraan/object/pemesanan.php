<?php

class Pemesanan {

    private $conn;
    private $table_name = "pemesanan";
    
    public $ID;
    public $Namadriver;
    public $Jenismobil;
    public $Penempatanjalur;
    public $Pihaksetuju;
    public $TglPemesanan;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    function create() {
        $query = "INSERT INTO " . $this->table_name . " (Namadriver, Jenismobil, Penempatanjalur, Pihaksetuju, TglPemesanan) VALUES (:Namadriver, :Jenismobil, :Penempatanjalur, :Pihaksetuju, :TglPemesanan)";
        $result = $this->conn->prepare($query);
        
        $this->Namadriver = htmlspecialchars(strip_tags($this->Namadriver));
        $this->Jenismobil = htmlspecialchars(strip_tags($this->Jenismobil));
        $this->Penempatanjalur = htmlspecialchars(strip_tags($this->Penempatanjalur));
        $this->Pihaksetuju = htmlspecialchars(strip_tags($this->Pihaksetuju));
        $this->TglPemesanan = date("Y-m-d");
        
        $result->bindParam(":Namadriver", $this->Namadriver);
        $result->bindParam(":Jenismobil", $this->Jenismobil);
        $result->bindParam(":Penempatanjalur", $this->Penempatanjalur);
        $result->bindParam(":Pihaksetuju", $this->Pihaksetuju);
        $result->bindParam(":TglPemesanan", $this->TglPemesanan);
        
        if($result->execute()) {
            return true;
        } else {
            return false;
        }
    }
    
    function readALL() {
        $query = "SELECT * FROM " . $this->table_name;

        $result = $this->conn->prepare($query);
        $result->execute();

        return $result;
    }
    
    function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);
        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->Namadriver = $row["Namadriver"];
        $this->Jenismobil = $row["Jenismobil"];
        $this->Penempatanjalur = $row["Penempatanjalur"];
        $this->Pihaksetuju = $row["Pihaksetuju"];
    }

    function update() {
        $query = "UPDATE " . $this->table_name . " SET Namadriver = :Namadriver, Jenismobil = :Jenismobil, Penempatanjalur = :Penempatanjalur, Pihaksetuju = :Pihaksetuju WHERE ID = :ID";
        $result = $this->conn->prepare($query);
    
        $this->Namadriver = htmlspecialchars(strip_tags($this->Namadriver));
        $this->Jenismobil = htmlspecialchars(strip_tags($this->Jenismobil));
        $this->Penempatanjalur = htmlspecialchars(strip_tags($this->Penempatanjalur));
        $this->Pihaksetuju = htmlspecialchars(strip_tags($this->Pihaksetuju));
    
        $result->bindParam(":Namadriver", $this->Namadriver);
        $result->bindParam(":Jenismobil", $this->Jenismobil);
        $result->bindParam(":Penempatanjalur", $this->Penempatanjalur);
        $result->bindParam(":Pihaksetuju", $this->Pihaksetuju);
        $result->bindParam(":ID", $this->ID);

        $result->execute();
    }

    function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE ID = ?";

        $result = $this->conn->prepare($query);
        $result->bindParam(1, $this->ID);

        $result->execute();
    }
}
?>
