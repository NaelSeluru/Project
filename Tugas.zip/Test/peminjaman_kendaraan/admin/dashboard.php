<?php
   include '../config/layout.php';
?>

<div class="p-4 sm:ml-64">
   <div class="p-4 mt-14">
   <h1 class="mb-4 text-4xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-6xl dark:text-dark">PT. Tambang Nikel Irian Jaya</h1>
<p class="mb-6 text-lg font-normal text-gray-500 lg:text-xl dark:text-dark-400">Selamat datang, Ini adalah platform untuk peminjaman kendaraan dari perusahaan untuk memantu keperluan dan kebutuhan driver supaya berguna untuk perusahaan</p>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <canvas id="myChart" width="400" height="200"></canvas>
    <script>
        fetch('pemakaian.php')
        .then(response => response.json())
        .then(data => {
            const labels = data.map(row => row.tanggal);
            const values = data.map(row => row.jarak);

            const ctx = document.getElementById('myChart').getContext('2d');
            const myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Jarak Pemakaian (km)',
                        data: values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
    </script>
   </div>
</div>
</body>
</html>