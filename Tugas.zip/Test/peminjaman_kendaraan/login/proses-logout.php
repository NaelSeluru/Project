<?php

session_start();

if(isset($_SESSION["idpengguna"])){
    
    $_SESSION = array();

    session_destroy();
}

header("Location: http://localhost/peminjaman_kendaraan/login/index.php");

?>