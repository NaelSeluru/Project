<?php
session_start();

if($_POST) {
    include '../config/Database.php';
    include '../object/pengguna.php';

    $database = new Database();
    $db = $database->getConnection();

    $pengguna = new Pengguna($db);

    $pengguna->Email = $_POST["email"];
    $pengguna->Password = $_POST["password"];

    if($pengguna->authenticate()) {
        if (strpos($pengguna->Email, '@admin') !== false) {
            header("Location: http://localhost/peminjaman_kendaraan/admin/dashboard.php");
        } elseif (strpos($pengguna->Email, '@atasan') !== false) {
            header("Location: http://localhost/peminjaman_kendaraan/atasan/dashboard.php");
        } else {
            header("Location: http://localhost/peminjaman_kendaraan/login/index.php");
        }
    } 
}
?>
