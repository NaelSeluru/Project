<?php
if ($_GET["ID"]) {
    include "../config/Database.php";
    include "../object/pengguna.php";

    $database = new Database();
    $db = $database->getConnection();

    $pengguna = new pengguna($db);
    $pengguna->ID = $_GET["ID"];

    $pengguna->delete();
}

header("Location: http://localhost/peminjaman_kendaraan/pengguna/index.php");
?>