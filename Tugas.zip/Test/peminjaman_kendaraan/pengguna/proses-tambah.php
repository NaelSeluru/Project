<?php
if ($_POST) {
    include "../config/Database.php";
    include "../object/pengguna.php";

    $database = new Database();
    $db = $database->getConnection();

    $pengguna = new pengguna($db);

    $pengguna->Email = $_POST["email"];
    $pengguna->Password = $_POST["password"];

    $pengguna->create();    
}

header("Location: http://localhost/peminjaman_kendaraan/pengguna/index.php");
?>